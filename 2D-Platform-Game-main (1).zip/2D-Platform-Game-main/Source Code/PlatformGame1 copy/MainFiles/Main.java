//Craig Benjamin
package MainFiles;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.*;
import MainFiles.*;

public class Main{
    public static void main(String[] args){
        new Game();
        System.out.println("Welcome to the game.");


    }
}
