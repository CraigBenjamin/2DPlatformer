package MainFiles;

public interface Dimension {

}
