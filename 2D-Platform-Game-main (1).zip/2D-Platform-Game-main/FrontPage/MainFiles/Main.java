//Craig Benjamin
package MainFiles;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.*;
import MainFiles.*;

public class Main extends Applet{
    public static void main(String[] args){
        new Game();
        System.out.println("Welcome to the game.");


    }
}
