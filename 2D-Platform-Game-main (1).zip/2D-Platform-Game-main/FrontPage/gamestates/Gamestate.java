package gamestates;

public enum Gamestate {

    PLAYING, MENU, OPTIONS, QUIT, CHANGESKIN; 

    public static Gamestate state = MENU;
    
}
